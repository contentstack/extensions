[![Contentstack](/youtube/youtube-extension-popup/public/contentstack.png)](https://www.contentstack.com/)

## Steps required to create new build

First the app in vscode or any editor if your preference.
Then fire up the terminal in root directory of the project and used following command

```
npm install
npm run build
or
yarn 
yarn build
```
After creating the build open up the stack where we are using this app.
Goto to the assets section and select add assets.
Now browse the directories fetch index.html from build folder of this project.