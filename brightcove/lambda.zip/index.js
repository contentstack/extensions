const axios = require('axios');

const authBaseUrl = "https://oauth.brightcove.com";
const cmsBaseUrl = "https://cms.api.brightcove.com";
const { clientId, clientSecret } = process.env;
const authString = `client_id=${clientId}&client_secret=${clientSecret}&grant_type=client_credentials`;

function getData(dataObj) {
  console.log("making call", dataObj);
  return new Promise((resolve, reject) => {
    const config = {
      method: dataObj.method,
      url: dataObj.url,
      headers: dataObj.headers,
    };
    if (dataObj.data) {
      config["data"] = dataObj.data;
    }
    axios(config)
      .then((response) => resolve(response.data))
      .catch((error) => reject(error));
  });
}

exports.handler = async (event) => {
  const body = JSON.parse(event.body);

  if (!event.queryStringParameters) {
    return {
      statusCode: 422,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ error: 'Invalid request' }),
    };
  } else {
    try {
      const { authUrl } = body;
      const authHeader = {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/x-www-form-urlencoded',
      };

      const authResponse = await getData({
        method: 'POST',
        url: authBaseUrl + authUrl,
        headers: authHeader,
        data:authString
      });
      
      console.log("auth", authResponse.access_token);

      const { videoUrl } = body;
      const videoHeader = {
        'Access-Control-Allow-Origin': '*',
        Authorization: `Bearer ${authResponse.access_token}`,
      };

      const getVideos = await getData({
        method: 'GET',
        url: cmsBaseUrl + videoUrl,
        headers: videoHeader,
      });
      return {
        statusCode: 200,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(getVideos),
      };
    } catch (error) {
      console.log(error);
      return {
        statusCode: 500,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: error.name,
          code: error.code,
          message: error.message,
        }),
      };
    }
  }
};
